import os,time,requests,json,glob,sqlite3,serial,Adafruit_DHT
from datetime import datetime

def send_alert(url,)


	
def update_actuator(url,ac_id,onoff):
	data = {'actuator':[{'ac_id':ac_id},{'onoff':onoff}]}
	sendrequest(url,data)
	
url = "http://vinoothna1998.pythonanywhere.com/update"


ser=serial.Serial('/dev/ttyACM2',9600)

import RPi.GPIO as GPIO
from time import sleep
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
vcc1 = 13
vcc2 = 15
GPIO.setup(vcc1,GPIO.OUT)
GPIO.output(vcc1,GPIO.LOW)
GPIO.setup(vcc2,GPIO.OUT)
GPIO.output(vcc2,GPIO.LOW)

print("in loop")
h,t = Adafruit_DHT.read_retry(Adafruit_DHT.DHT11, 23)
	
read_serial=ser.readline().split('=')
if len(read_serial)==4:
    sm1 = str(int(read_serial[0],16))
    sm2 = str(int(read_serial[1],16))
    us = str(int(read_serial[2],16))
    #mot_stat = str(int(read_serial[2],16)) 
    water_level =str(int(read_serial[3][:-2],16))

    mot_stat1=0
    mot_stat2=0
    #update_actuator(url,1,mot_stat1)
    #update_actuator(url,2,mot_stat2)
    if(int(sm1)<=50):
        sm1=str(0)
        if int(water_level)<=10 and int(us)<=10:
            print "Turning motor1 on"
            GPIO.output(vcc1,GPIO.HIGH)
            mot_stat1=1
            update_actuator(url,1,str(mot_stat1))
            sleep(5)
            print "Turning motor1 off"
            GPIO.output(vcc1,GPIO.LOW)
            #mot_stat1=0
            #GPIO.cleanup()
    if(int(sm2)<=0):
        sm2=str(0)
        if int(water_level)<=10 and int(us)<=10:
            print "Turning motor2 on"
            GPIO.output(vcc2,GPIO.HIGH)
            mot_stat2=1
            update_actuator(url,2,str(mot_stat2))
            sleep(5)
            print "Turning motor2 off"
            GPIO.output(vcc2,GPIO.LOW)
            #mot_stat2=0
            #GPIO.cleanup()
    print("soil moisture1 :",sm1,"    soil moisture2 :",sm2)
    print("temperature :",t,"    humidity :",h)
    print("water tank :",us,"     rain :",water_level)
    print("motor1 :",mot_stat1,"      motor2 :",mot_stat2)
    print("---------------------------------------------------------\n")
    update_soil_moisture(url,1,float(sm1))
    update_soil_moisture(url,2,float(sm2))
    update_waterlevel(url,1,float(us))
    update_actuator(url,1,str(mot_stat1))
    update_actuator(url,2,str(mot_stat2))
    update_climate(url,1,float(t),float(h),int(water_level))

        #time.sleep(1)

