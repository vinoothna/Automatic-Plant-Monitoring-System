import requests
import json
from datetime import datetime

def sendrequest(url,data):
	r=requests.post(url, data=json.dumps(data), headers={'content-type': 'application/json'})

def update_soil_moisture(url,plant_id,sm_value):
	data = {'soilmoisture':[{'plant_id':plant_id}, {'soilmoisture':sm_value}]}
	sendrequest(url,data)

def update_climate(url,ws_id,temp,humi,rain):
	time=datetime.now()
	data = {'climate':[{'ws_id':ws_id}, {'temp':temp},{'humi':humi},{'raining':rain}]}
	sendrequest(url,data)

def update_waterlevel(url,wb_id,waterlevel):
	data = {'waterlevel':[{'wb_id':wb_id}, {'waterlevel':waterlevel}]}
	sendrequest(url,data)
	
def update_actuator(url,ac_id,onoff):
	data = {'actuator':[{'ac_id':ac_id},{'onoff':onoff}]}
	sendrequest(url,data)
	
url = "http://vinoothna1998.pythonanywhere.com/update"

#update_soil_moisture(url,1,20)
#update_waterlevel(url,1,30)
update_actuator(url,1,'0')
update_actuator(url,2,'0')

#update_climate(url,1,33,22,9)